package com.techbrowse.techchat

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.ByteArrayInputStream
import android.content.Intent
import androidx.compose.foundation.isSystemInDarkTheme
import android.content.SharedPreferences
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.delay

fun load(p: SharedPreferences, k: String) =
    p.getString(k, "")!!.lines().filter { it.contains("\t") }.map { it.split("\t") }

val Blue = Color(0xFF1A73E8)
val LightC = lightColorScheme(primary = Blue, background = Color.White, surface = MaterialTheme.colorScheme.surface, surfaceVariant = MaterialTheme.colorScheme.surfaceVariant)
val DarkC = darkColorScheme(primary = Blue, background = Color(0xFF0F1722), surface = Color(0xFF18212F), surfaceVariant = Color(0xFF142238))
val Navy = Color(0xFF0B1B33)
val TRACKERS = listOf("doubleclick.net", "google-analytics.com", "googlesyndication.com",
    "facebook.net", "scorecardresearch.com", "taboola.com", "outbrain.com", "adservice.google")
@Volatile var blockOn = true
const val DESK = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

class Tab(val incognito: Boolean) {
    var url by mutableStateOf("")
    var title by mutableStateOf("New Tab")
    var web: WebView? = null
    var desk = false
}

fun resolve(q: String, engine: String): String {
    val s = q.trim()
    if (s.startsWith("http://") || s.startsWith("https://")) return s
    if (!s.contains(" ") && s.contains(".")) return "https://$s"
    val e = Uri.encode(s)
    return when (engine) {
        "DuckDuckGo" -> "https://duckduckgo.com/?q=$e"
        "Bing" -> "https://www.bing.com/search?q=$e"
        else -> "https://www.google.com/search?q=$e"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val prefs = remember { getSharedPreferences("tb", 0) }
            var theme by remember { mutableStateOf(prefs.getString("theme", "System")!!) }
            val dark = when (theme) { "Dark" -> true; "Light" -> false; else -> isSystemInDarkTheme() }
            MaterialTheme(colorScheme = if (dark) DarkC else LightC) {
                Surface(Modifier.fillMaxSize()) {
                    App(theme) { theme = it; prefs.edit().putString("theme", it).apply() }
                }
            }
        }
    }
}

@Composable
fun App(theme: String, onTheme: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("tb", 0) }
    val tabs = remember { mutableStateListOf(Tab(false)) }
    var cur by remember { mutableStateOf(tabs[0]) }
    var screen by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var marks by remember { mutableStateOf(load(prefs, "m")) }
    var reads by remember { mutableStateOf(load(prefs, "r")) }
    var hist by remember { mutableStateOf(load(prefs, "h")) }
    var dls by remember { mutableStateOf(load(prefs, "d")) }
    var filter by remember { mutableStateOf("All") }
    var home by remember { mutableStateOf(prefs.getString("home", "Default")!!) }
    var splash by remember { mutableStateOf(true) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "English")!!) }
    LaunchedEffect(Unit) { delay(1600); splash = false }
    LaunchedEffect(cur) { CookieManager.getInstance().setAcceptCookie(!cur.incognito) }
    var block by remember { mutableStateOf(prefs.getBoolean("b", true)) }
    var desk by remember { mutableStateOf(false) }
    var engine by remember { mutableStateOf(prefs.getString("e", "Google")!!) }
    blockOn = block

    fun store(k: String, m: List<List<String>>) {
        prefs.edit().putString(k, m.joinToString("\n") { it[0].replace(Regex("[\t\n]"), " ") + "\t" + it[1] }).apply()
    }
    fun saveMarks(m: List<List<String>>) { marks = m; store("m", m) }
    fun saveReads(m: List<List<String>>) { reads = m; store("r", m) }
    fun visit(t: String, u: String) { if (u.startsWith("http")) { hist = (listOf(listOf(t, u)) + hist).take(200); store("h", hist) } }
    fun addDl(n: String, u: String) { dls = (listOf(listOf(n, u)) + dls).take(100); store("d", dls) }
    fun go(u: String) { val r = resolve(u, engine); screen = ""; cur.url = r
        val code = mapOf("English" to "en", "Español" to "es", "Français" to "fr", "Deutsch" to "de")[lang] ?: "en"
        cur.web?.loadUrl(r, mapOf("Accept-Language" to code)) }
    fun newTab(inc: Boolean) { val t = Tab(inc); if (!inc && home != "Google") t.url = "" else if (!inc) t.url = "https://www.google.com"; tabs.add(t); cur = t; screen = "" }

    BackHandler(enabled = screen != "" || cur.url != "") {
        when {
            screen != "" -> screen = ""
            cur.web?.canGoBack() == true -> cur.web?.goBack()
            else -> cur.url = ""
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().systemBarsPadding().background(MaterialTheme.colorScheme.background)) {
        Box(Modifier.weight(1f)) {
            when (screen) {
                "tabs" -> Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(12.dp)) {
                    Text("Tabs", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(tabs.toList()) { t ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { cur = t; screen = "" },
                                colors = CardDefaults.cardColors(containerColor = if (t.incognito) Navy else MaterialTheme.colorScheme.background)) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        val c = if (t.incognito) Color.White else MaterialTheme.colorScheme.onBackground
                                        Text(if (t.incognito) "Incognito: ${t.title}" else t.title, color = c, maxLines = 1)
                                        Text(t.url.ifEmpty { "Start page" }, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                                    }
                                    IconButton(onClick = {
                                        if (t.incognito) { t.web?.clearCache(true); t.web?.clearHistory() }
                                        t.web?.destroy(); tabs.remove(t)
                                        if (tabs.isEmpty()) tabs.add(Tab(false))
                                        if (cur === t) cur = tabs.last()
                                    }) { Icon(Icons.Default.Close, "Close", tint = Color.Gray) }
                                }
                            }
                        }
                    }
                    Button({ newTab(false) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("+ New Tab") }
                }
                "marks" -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All", "Reading List").forEach { f -> FilterChip(filter == f, { filter = f }, { Text(f) }) }
                    }
                    val list = if (filter == "All") marks else reads
                    if (list.isEmpty()) Text("Nothing here yet. Use the Menu to add pages.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                    LazyColumn {
                        items(list) { m ->
                            Row(Modifier.fillMaxWidth().clickable { go(m[1]) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(m[0], maxLines = 1); Text(m[1], color = Color.Gray, fontSize = 12.sp, maxLines = 1) }
                                IconButton({ if (filter == "All") saveMarks(marks - listOf(m)) else saveReads(reads - listOf(m)) }) { Icon(Icons.Default.Delete, "Delete", tint = Color.Gray) }
                            }
                        }
                    }
                }
                "hist" -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("History", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        TextButton({ hist = emptyList(); store("h", hist) }) { Text("Clear") }
                    }
                    LazyColumn {
                        items(hist) { m ->
                            Column(Modifier.fillMaxWidth().clickable { go(m[1]) }.padding(8.dp)) {
                                Text(m[0], maxLines = 1); Text(m[1], color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                }
                "dls" -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Text("Downloads", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                    if (dls.isEmpty()) Text("No downloads yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                    LazyColumn {
                        items(dls) { m ->
                            Column(Modifier.fillMaxWidth().padding(8.dp)) {
                                Text(m[0], maxLines = 1); Text("Saved to your Downloads folder", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
                "settings" -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    SRow("Search Engine", engine) {
                        engine = when (engine) { "Google" -> "DuckDuckGo"; "DuckDuckGo" -> "Bing"; else -> "Google" }
                        prefs.edit().putString("e", engine).apply()
                    }
                    SRow("Block Trackers", if (block) "On" else "Off") { block = !block; prefs.edit().putBoolean("b", block).apply() }
                    SRow("Theme", theme) { onTheme(when (theme) { "System" -> "Light"; "Light" -> "Dark"; else -> "System" }) }
                    SRow("Language (web pages)", lang) {
                        lang = when (lang) { "English" -> "Español"; "Español" -> "Français"; "Français" -> "Deutsch"; else -> "English" }
                        prefs.edit().putString("lang", lang).apply()
                    }
                    SRow("Homepage", home) { home = if (home == "Default") "Google" else "Default"; prefs.edit().putString("home", home).apply() }
                    SRow("Safe Browsing", "On") {}
                    SRow("Clear Browsing Data", ">") {
                        CookieManager.getInstance().removeAllCookies(null)
                        WebStorage.getInstance().deleteAllData()
                        tabs.forEach { it.web?.clearCache(true); it.web?.clearHistory() }
                        hist = emptyList(); store("h", hist)
                    }
                    SRow("Version", "1.0") {}
                    SRow("Rate the App", ">") {
                        val id = "com.techbrowse.techchat"
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$id")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        catch (_: Exception) { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$id")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
                    }
                }
                else -> if (cur.url.isEmpty()) Home(cur, ::go) { screen = "marks" } else Column(Modifier.fillMaxSize()) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        UrlBar(cur.url, Modifier.weight(1f), ::go)
                        IconButton({ cur.web?.reload() }) { Icon(Icons.Default.Refresh, "Reload") }
                    }
                    key(cur) { WebTab(cur, desk, ctx, ::visit, ::addDl) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
            Nav(Icons.Default.Home, "Home") { screen = ""; cur.url = "" }
            Nav(Icons.Default.Star, "Bookmarks") { screen = "marks" }
            Nav(Icons.Default.List, "Tabs ${tabs.size}") { screen = "tabs" }
            Box {
                Nav(Icons.Default.Menu, "Menu") { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("New Tab") }, { menu = false; newTab(false) })
                    DropdownMenuItem({ Text("New Incognito Tab") }, { menu = false; newTab(true) })
                    if (cur.url.isNotEmpty()) DropdownMenuItem({ Text("Bookmark this page") }, {
                        menu = false; saveMarks(marks + listOf(listOf(cur.title.ifEmpty { cur.url }, cur.url)))
                    })
                    if (cur.url.isNotEmpty() && !cur.incognito) DropdownMenuItem({ Text("Add to Reading List") }, {
                        menu = false; saveReads(reads + listOf(listOf(cur.title.ifEmpty { cur.url }, cur.url)))
                    })
                    DropdownMenuItem({ Text("History") }, { menu = false; screen = "hist" })
                    DropdownMenuItem({ Text("Downloads") }, { menu = false; screen = "dls" })
                    DropdownMenuItem({ Text("Desktop Site") }, { desk = !desk },
                        trailingIcon = { Switch(desk, { desk = it }) })
                    DropdownMenuItem({ Text("Settings") }, { menu = false; screen = "settings" })
                    DropdownMenuItem({ Text("Help & Feedback") }, {
                        menu = false
                        try { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:techatchat.ai.com@gmail.com?subject=Tech%20Browse%20Feedback")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    })
                    HorizontalDivider()
                    DropdownMenuItem({ Column { Text("Browse Safe", color = Blue); Text("Your privacy matters", fontSize = 11.sp, color = Color.Gray) } },
                        { menu = false; screen = "settings" })
                }
            }
        }
    }
    if (splash) Splash()
    }
}

@Composable
fun WebTab(t: Tab, desk: Boolean, ctx: Context, onVisit: (String, String) -> Unit, onDl: (String, String) -> Unit) {
    AndroidView(Modifier.fillMaxSize(), factory = { c ->
        t.web?.also { (it.parent as? ViewGroup)?.removeView(it) } ?: WebView(c).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = !t.incognito
            settings.safeBrowsingEnabled = true
            if (t.incognito) { settings.cacheMode = WebSettings.LOAD_NO_CACHE; settings.saveFormData = false }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    val h = r.url.host ?: return null
                    return if (blockOn && TRACKERS.any { h.contains(it) })
                        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))) else null
                }
                override fun onPageStarted(v: WebView, url: String, f: android.graphics.Bitmap?) { t.url = url }
                override fun onPageFinished(v: WebView, url: String) { t.title = v.title ?: url; if (!t.incognito) onVisit(t.title, url) }
            }
            setDownloadListener { url, _, cd, mime, _ ->
                try {
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
                    (c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req); onDl(URLUtil.guessFileName(url, cd, mime), url)
                } catch (_: Exception) {}
            }
            t.web = this
            loadUrl(t.url)
        }
    }, update = {
        if (t.desk != desk) {
            t.desk = desk
            it.settings.userAgentString = if (desk) DESK else null
            it.reload()
        }
    })
}

@Composable
fun UrlBar(text: String, modifier: Modifier = Modifier, onGo: (String) -> Unit) {
    var v by remember(text) { mutableStateOf(text) }
    OutlinedTextField(v, { v = it }, modifier, singleLine = true, shape = RoundedCornerShape(24.dp),
        placeholder = { Text("Search or type URL") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri),
        keyboardActions = KeyboardActions(onGo = { if (v.isNotBlank()) onGo(v) }))
}

@Composable
fun Logo(size: Int) = Image(painterResource(R.drawable.logo), "Tech Browse", Modifier.size(size.dp).clip(RoundedCornerShape((size / 4).dp)))

@Composable
fun Splash() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Logo(110)
        Text("Tech Browse", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(top = 16.dp))
        Text("Fast  •  Secure  •  Smart", color = Color.Gray)
        LinearProgressIndicator(Modifier.padding(top = 32.dp).width(80.dp), color = Blue)
    }
}

@Composable
fun Shortcut(n: String, u: String, go: (String) -> Unit) {
    Column(Modifier.clickable { go(u) }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            Text(n.take(1), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Blue)
        }
        Text(n, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun Home(t: Tab, go: (String) -> Unit, onMarks: () -> Unit) {
    val d = t.incognito
    var ack by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(if (d) Navy else MaterialTheme.colorScheme.surfaceVariant).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(32.dp))
        if (!d) Logo(72)
        Text(if (d) "Incognito Mode" else "Tech Browse", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            color = if (d) Color.White else Blue, modifier = Modifier.padding(top = 8.dp))
        if (!(d && ack)) Text(if (d) "Your activity won't be saved. Pages you visit, searches and form entries won't be stored on this device. Cookies are off while this tab is open."
             else "Fast  •  Secure  •  Smart", color = if (d) Color(0xFFB0BCD0) else Color.Gray,
            modifier = Modifier.padding(vertical = 8.dp))
        Spacer(Modifier.height(12.dp))
        UrlBar("", Modifier.fillMaxWidth(), go)
        if (d && !ack) {
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("No History", "No Cookies", "More Privacy").forEach {
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF16294A)).padding(12.dp), contentAlignment = Alignment.Center) {
                        Text(it, color = Color(0xFFB0BCD0), fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Button({ ack = true }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("Got it") }
        }
        if (!d) {
            Spacer(Modifier.height(24.dp))
            val rows = listOf(listOf("Google" to "google.com", "YouTube" to "youtube.com", "GitHub" to "github.com", "Wikipedia" to "wikipedia.org"),
                listOf("Facebook" to "facebook.com", "X" to "x.com", "Instagram" to "instagram.com", "OpenAI" to "openai.com"))
            rows.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    r.forEach { (n, u) -> Shortcut(n, u, go) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Quick Access", fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
            Card(Modifier.fillMaxWidth().padding(top = 8.dp).clickable { go("techcrunch.com") }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)) {
                Column(Modifier.padding(12.dp)) { Text("Tech News"); Text("Latest technology updates", fontSize = 12.sp, color = Color.Gray) }
            }
            Card(Modifier.fillMaxWidth().padding(top = 8.dp).clickable(onClick = onMarks), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)) {
                Column(Modifier.padding(12.dp)) { Text("Bookmarks"); Text("Your saved websites", fontSize = 12.sp, color = Color.Gray) }
            }
        }
    }
}

@Composable
fun Nav(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = Blue); Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun SRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, color = Color.Gray)
    }
    HorizontalDivider()
}
